# vLLM Podman Quadlet Role

Enterprise-grade Ansible role for deploying **vLLM** via **Podman Quadlets** on **Rocky Linux 9.7** systems hardened to DISA STIG baselines.

## Hardening Stack

| Layer | Implementation |
|---|---|
| **FIPS 140-3** | Host OpenSSL + PKI trust store mounted read-only; `OPENSSL_FORCE_FIPS_MODE=1` |
| **SELinux** | `container_use_devices=true` boolean; model dir labeled `container_file_t` |
| **fapolicyd** | Trust rules for NVIDIA CDI binaries and `/var/lib/containers/storage` |
| **DISA STIG** | Non-root service user, `journald` logging, `NoNewPrivileges`, `ProtectSystem=strict` |
| **NVIDIA CDI** | `Device=nvidia.com/gpu=all`; auto-generates CDI spec if missing |

## GPU Presets

| Preset | VRAM | `gpu_memory_utilization` | `max_model_len` |
|---|---|---|---|
| `4000` | 24 GB | 0.75 | 32,768 |
| `6000` | 96 GB | 0.90 | 131,072 |

Select with: `vllm_gpu_preset: "6000"`

## Quick Start

```yaml
- hosts: inference_nodes
  become: true
  roles:
    - role: vllm_quadlet
      vars:
        vllm_gpu_preset: "6000"
        vllm_model_name: "meta-llama/Llama-3.1-70B-Instruct"
```

## Requirements

- Rocky Linux 9.7+
- Podman 4.x+ with Quadlet support
- NVIDIA Container Toolkit (`nvidia-ctk`)
- Ansible Collections: `ansible.posix`, `community.general`, `containers.podman`

## File Layout

```
vllm_quadlet_role/
├── defaults/main.yml                     # All tunables + GPU presets
├── tasks/main.yml                        # Orchestration with hardening logic
├── handlers/main.yml                     # fapolicyd, SELinux, systemd handlers
├── templates/
│   ├── vllm.container.j2                 # Podman Quadlet unit
│   ├── fapolicyd-vllm.trust.j2           # fapolicyd trust entries
│   └── fapolicyd-vllm-rules.j2           # fapolicyd execution rules
└── meta/main.yml                         # Galaxy metadata + dependencies
```
