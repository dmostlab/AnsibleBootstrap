# Podman Base Role

Install and harden **Podman** on **Rocky Linux 9.7** systems with DISA STIG, SELinux Enforcing, FIPS, and fapolicyd. This role is the prerequisite for both `vllm_quadlet` and `litellm_quadlet`.

## What It Does

- Installs Podman, crun, slirp4netns, container-selinux, udica, skopeo, buildah
- Deploys hardened `storage.conf`, `registries.conf`, and `containers.conf`
- Restricts registries to an approved allowlist (`short-name-mode = "enforcing"`)
- Forces `journald` as the default log driver and events logger (STIG)
- Sets `no_new_privileges = true` as the container default
- Deploys fapolicyd trust (priority `50-`) for Podman binaries and `/var/lib/containers/storage`
- Labels container storage with `container_var_lib_t` via SELinux
- Configures sysctl tuning for container networking
- Creates `/etc/containers/systemd` for Quadlet unit files
- Manages subuid/subgid ranges for rootless container users
- Validates FIPS mode and overlay driver with a smoke test

## Playbook Ordering

```yaml
- hosts: inference_nodes
  become: true
  roles:
    - role: podman_base                    # ← Install + harden Podman first
    - role: vllm_quadlet
      vars:
        vllm_gpu_preset: "6000"
    - role: litellm_quadlet
      vars:
        litellm_master_key: "{{ foreman_litellm_master_key }}"
        litellm_pg_password: "{{ foreman_litellm_pg_password }}"
```

## fapolicyd Priority Scheme

| Priority | File | Role |
|---|---|---|
| `50-` | `podman-base.trust` / `.rules` | This role |
| `60-` | `vllm-nvidia.trust` / `.rules` | `vllm_quadlet` |
| `61-` | `litellm.trust` / `.rules` | `litellm_quadlet` |

## Requirements

- Rocky Linux 9.7+
- Ansible Collections: `ansible.posix`, `community.general`
