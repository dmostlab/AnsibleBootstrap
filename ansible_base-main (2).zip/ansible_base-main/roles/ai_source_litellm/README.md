# LiteLLM Proxy Podman Quadlet Role

Enterprise-grade Ansible role for deploying **LiteLLM Proxy** via **Podman Quadlets** on **Rocky Linux 9.7**, hardened to DISA STIG baselines. Designed as the API gateway layer in front of vLLM inference backends.

## Architecture

```
 Team Network
      │
      ▼ :4000
┌─────────────┐       ┌──────────────────┐
│  LiteLLM    │──────▶│  vLLM Workhorse  │ :8000  (always-on, high-context)
│  Proxy      │       └──────────────────┘
│  (Quadlet)  │       ┌──────────────────┐
│             │──────▶│  vLLM Flexible   │ :8000 or :8001  (sleep-mode)
└─────────────┘       └──────────────────┘
      │
      ▼
┌─────────────┐
│ PostgreSQL  │  Virtual keys, spend tracking
│  (local)    │
└─────────────┘
```

## Hardening Stack

| Layer | Implementation |
|---|---|
| **FIPS 140-3** | Host PKI + crypto-policies mounted read-only; `OPENSSL_FORCE_FIPS_MODE=1` |
| **SELinux** | Config and secrets labeled `container_file_t` |
| **fapolicyd** | Trust rules for container storage Python execution |
| **DISA STIG** | Non-root user, `journald` logging, `NoNewPrivileges`, `PrivateDevices` |

## Secrets Management

Secrets are injected by **Foreman** as Ansible variables via Smart Class Parameters:

| Variable | Source |
|---|---|
| `litellm_master_key` | Foreman Host Parameter (encrypted) |
| `litellm_pg_password` | Foreman Host Parameter (encrypted) |

The role validates that placeholder values have been replaced before proceeding.

## Model Routing

| Route | Purpose | Default Backend | Concurrency |
|---|---|---|---|
| **Workhorse** (`gpt-4`) | High-context, always-on | `localhost:8000` | `max_parallel_requests: 2` |
| **Flexible** (`gpt-3.5-turbo`) | Model rotation, sleep-mode | `localhost:8000` (configurable to `:8001`) | `max_parallel_requests: 4` |

### Dual-Instance Pattern

Override in Foreman to point the flexible route at a second vLLM:

```yaml
litellm_flexible:
  group_name: "flexible"
  display_model: "gpt-3.5-turbo"
  models:
    - model_name: "gpt-3.5-turbo"
      litellm_model: "openai/meta-llama/Llama-3.1-8B-Instruct"
      api_base: "http://host.containers.internal:8001/v1"
      api_key: "token-placeholder"
      max_parallel_requests: 4
```

## Quick Start

```yaml
- hosts: inference_nodes
  become: true
  roles:
    - role: vllm_quadlet
      vars:
        vllm_gpu_preset: "6000"
    - role: litellm_quadlet
      vars:
        litellm_master_key: "{{ foreman_litellm_master_key }}"
        litellm_pg_password: "{{ foreman_litellm_pg_password }}"
```

## Requirements

- Rocky Linux 9.7+
- Podman 4.x+ with Quadlet support
- Ansible Collections: `ansible.posix`, `community.general`, `community.postgresql`, `containers.podman`

## File Layout

```
litellm_quadlet_role/
├── defaults/main.yml                     # All tunables, Foreman secret vars, presets
├── tasks/
│   ├── main.yml                          # Orchestration with hardening logic
│   └── postgresql.yml                    # Local PostgreSQL setup
├── handlers/main.yml                     # fapolicyd, SELinux, systemd, PostgreSQL
├── templates/
│   ├── litellm.container.j2              # Podman Quadlet unit
│   ├── config.yaml.j2                    # LiteLLM router config
│   ├── fapolicyd-litellm.trust.j2        # fapolicyd trust entries
│   └── fapolicyd-litellm-rules.j2        # fapolicyd execution rules
└── meta/main.yml                         # Galaxy metadata + dependencies
```
