# Wazuh Agent Role

Installs and enrolls the Wazuh Agent on Linux hosts. Handles repository setup, optional enrollment parameters, and basic compliance hooks for FIPS, SELinux, and fapolicyd.

## What This Role Does

- Adds Wazuh repositories and GPG keys (APT/RPM).
- Installs `wazuh-agent` with optional enrollment environment variables.
- Enables and starts the `wazuh-agent` service.
- Restores SELinux contexts (optional).
- Installs fapolicyd rules (optional).
- Disables the Wazuh repo after install (optional).

## Defaults

- `wazuh_agent_protocol: tcp`
- `wazuh_agent_manager_port: 1514`
- `wazuh_agent_registration_port: 1515`
- `wazuh_fips_enabled: true`
- `wazuh_agent_disable_repo_after_install: true`

## Key Variables

### Enrollment / Registration

- `wazuh_agent_manager` (string)
- `wazuh_agent_managers` (list)
- `wazuh_agent_manager_port` (int)
- `wazuh_agent_protocol` (string)
- `wazuh_agent_registration_server` (string)
- `wazuh_agent_registration_port` (int)
- `wazuh_agent_registration_password` (string)
- `wazuh_agent_registration_ca` (string)
- `wazuh_agent_registration_certificate` (string)
- `wazuh_agent_registration_key` (string)
- `wazuh_agent_name` (string)
- `wazuh_agent_group` (string)
- `wazuh_agent_keep_alive_interval` (string)
- `wazuh_agent_time_reconnect` (string)
- `wazuh_agent_enrollment_delay` (string)

### FIPS / SELinux / fapolicyd

- `wazuh_fips_enabled` (bool, default `true`)
- `wazuh_agent_selinux_manage` (bool, default `true`)
- `wazuh_agent_selinux_restorecon_paths` (list)
- `wazuh_agent_fapolicyd_manage` (bool, default `true`)
- `wazuh_agent_fapolicyd_allow_paths` (list)

## Examples

### Basic Install (Set Manager)

```yaml
- hosts: wazuh_agents
  become: true
  roles:
    - role: wazuh_agent
      vars:
        wazuh_agent_manager: "10.0.0.10"
```

### Enrollment with Registration Password and Agent Name

```yaml
- hosts: wazuh_agents
  become: true
  roles:
    - role: wazuh_agent
      vars:
        wazuh_agent_manager: "10.0.0.10"
        wazuh_agent_registration_password: "changeme"
        wazuh_agent_name: "{{ inventory_hostname }}"
        wazuh_agent_group: "linux"
```
