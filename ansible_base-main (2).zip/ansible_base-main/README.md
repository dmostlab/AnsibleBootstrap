# ansible_base

Ansible baseline for a Rocky/RHEL 9 lab that provisions:

- RHEL 9 STIG baseline (`RedHatOfficial.rhel9_stig`)
- Foreman + Katello
- GitLab (CE/EE)
- Wazuh stack (Indexer, Manager, Dashboard)
- Wazuh agent deployment

## Repository Layout

- `site.yml`: Main playbook with role orchestration and tags.
- `inventory/lab_hosts.ini`: Inventory groups and host mappings.
- `group_vars/`: Environment and role override variables.
- `roles/`: Custom roles plus vendored STIG role.
- `requirements.yml`: External role/collection dependencies.
- `docs/`: Supplemental documentation (`docs/group_vars.md`, role doc pointers).

## Playbook Topology

Current `site.yml` applies roles in this order:

1. `all` -> `RedHatOfficial.rhel9_stig` (tag: `stig`)
2. `foreman_katello` -> `foreman_katello` (tag: `foreman`)
3. `wazuh_aio` -> `wazuh_indexer`, `wazuh_manager`, `wazuh_dashboard` (tag: `waz`)
4. `gitlab_main` -> `gitlab_ce` (tag: `gitlab`)
5. `all` -> `wazuh_agent` (tag: `waz_agent`)

## Prerequisites

- Control node with Ansible installed.
- SSH connectivity to targets.
- Privilege escalation rights (`become`).
- Required role/collections installed from `requirements.yml`.

Install dependencies:

```bash
ansible-galaxy install -r requirements.yml
```

## Inventory

Default inventory file:

- `inventory/lab_hosts.ini`

Defined groups:

- `foreman_katello`
- `gitlab_main`
- `wazuh_aio`

Update hostnames/IPs to match your environment before running.

## Configuration

Primary controller settings are in `ansible.cfg`.

Notable defaults:

- `inventory = ./inventory/lab_hosts.ini`
- `roles_path = ./roles`
- `remote_user = bigboss`
- `remote_tmp = ~/.ansible/tmp` (works better in hardened STIG/noexec `/tmp` environments)
- `become = True`

Role and environment variables are set in:

- `group_vars/all/vars.yml`
- Group-specific files under `group_vars/*/`
- Role defaults in `roles/<role>/defaults/main.yml`

Store secrets in vault files (`group_vars/*/vault.yml`) and avoid plaintext credentials in `vars.yml`.

## Usage

Run full baseline:

```bash
ansible-playbook site.yml
```

Run specific sections by tag:

```bash
ansible-playbook site.yml --tags stig
ansible-playbook site.yml --tags foreman
ansible-playbook site.yml --tags waz
ansible-playbook site.yml --tags gitlab
ansible-playbook site.yml --tags waz_agent
```

Run against a subset of hosts:

```bash
ansible-playbook site.yml --limit gitlab_main
ansible-playbook site.yml --limit wazuh_aio
```

## Role Notes

### `foreman_katello`

- Configures Pulp storage via LVM/XFS.
- Opens required firewalld ports.
- Installs Foreman/Katello packages and runs `foreman-installer --scenario katello`.

### `gitlab_ce`

- Supports `gitlab_edition: community|enterprise`.
- Configures GitLab package repo and installs package.
- Applies fapolicyd baseline/rules for GitLab paths.

### `wazuh_indexer`, `wazuh_manager`, `wazuh_dashboard`

- AIO-friendly defaults enabled.
- Handles package repo setup, service enable/start, certificate workflows, and hardening hooks (FIPS/SELinux/fapolicyd/firewalld).

### `wazuh_agent`

- Installs and enrolls agents with optional registration parameters.
- Supports manager list, registration creds, and agent metadata.

## Documentation

Role-specific documentation lives in each role:

- `roles/wazuh_indexer/README.md`
- `roles/wazuh_manager/README.md`
- `roles/wazuh_dashboard/README.md`
- `roles/wazuh_agent/README.md`

Additional docs:

- `docs/README.md`
- `docs/group_vars.md`

## Operational Tips

- Validate inventory and vars alignment before first run.
- Use `--check` where possible for dry-runs.
- Use vault for all passwords/tokens.
- For repeated runs in hardened environments, keep `remote_tmp` out of `/tmp`.
